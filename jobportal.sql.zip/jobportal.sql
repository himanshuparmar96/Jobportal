-- phpMyAdmin SQL Dump
-- version 3.1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2017 at 07:08 AM
-- Server version: 5.1.32
-- PHP Version: 5.2.9-1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jobportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `company_registration`
--

CREATE TABLE IF NOT EXISTS `company_registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(30) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `industry` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `contact_no` bigint(30) NOT NULL,
  `website` varchar(30) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `company_registration`
--

INSERT INTO `company_registration` (`id`, `company_name`, `email_id`, `user_name`, `password`, `industry`, `city`, `contact_no`, `website`, `address`) VALUES
(1, 'tcs', 'tcs@tcs.com', 'tcs', '123', 'IT/Computer-Software', 'Ahmedabad', 9586033348, 'tcs.com', 'ahmedabad');

-- --------------------------------------------------------

--
-- Table structure for table `jobseeker`
--

CREATE TABLE IF NOT EXISTS `jobseeker` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `user_name` varchar(25) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `jobseeker`
--

INSERT INTO `jobseeker` (`id`, `first_name`, `last_name`, `email`, `user_name`, `contact_no`, `gender`, `password`) VALUES
(3, 'parmar', 'himanshu', 'parmarhimanshu96@gmail.co', 'himanshu', 123, 'Male', '223');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `user_name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--


-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_title` varchar(30) NOT NULL,
  `job_description` varchar(500) NOT NULL,
  `job_location` varchar(30) NOT NULL,
  `skills` varchar(50) NOT NULL,
  `experience` int(5) NOT NULL,
  `salary` bigint(10) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `last_date_of_vacancy` date NOT NULL,
  `vacancy` bigint(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `job_title`, `job_description`, `job_location`, `skills`, `experience`, `salary`, `qualification`, `last_date_of_vacancy`, `vacancy`) VALUES
(1, 'software developer', 'software developer', 'Anand', 'php', 2, 50000, 'B.TECH', '2017-03-30', 10),
(2, 'software developer', 'software developer', 'Anand', 'php', 3, 50000, 'B.TECH', '2017-03-31', 10),
(3, 'software developer', 'software developer', 'Baroda', 'php', 3, 12345, 'MCA', '2017-03-31', 12),
(4, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(5, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(6, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(7, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(8, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(9, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(10, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(11, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(12, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(13, '', '', '', '', 0, 0, '', '0000-00-00', 0),
(14, '', '', '', '', 0, 0, '', '0000-00-00', 0);
